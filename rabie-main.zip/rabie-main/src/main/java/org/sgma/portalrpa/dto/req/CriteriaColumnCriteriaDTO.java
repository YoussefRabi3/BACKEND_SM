package org.sgma.portalrpa.dto.req;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CriteriaColumnCriteriaDTO {
    private String code;
    private String libelle;
}
