package org.sgma.portalrpa.dto.req;

import lombok.Data;

@Data
public class UserReq {
    private String fullName;
    private Long roleId;
}
