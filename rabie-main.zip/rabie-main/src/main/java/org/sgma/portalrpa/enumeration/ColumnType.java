package org.sgma.portalrpa.enumeration;

public enum ColumnType {
    MAIL,NUMERIC,DATE,RIB,NPP,NPM
}
