package org.sgma.portalrpa.enumeration;

public enum OriginRequest {
    UPLOADS,PANIER
}
