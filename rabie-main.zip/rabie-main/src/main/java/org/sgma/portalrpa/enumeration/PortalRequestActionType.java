package org.sgma.portalrpa.enumeration;

public enum PortalRequestActionType {
    INITIATION,VALIDATION
}
