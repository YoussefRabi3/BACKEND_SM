package org.sgma.portalrpa.enumeration;

public enum RPRoleName {
    INITIATOR,VALIDATOR,PILOTAGE
}
