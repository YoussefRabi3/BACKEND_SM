package org.sgma.portalrpa.enumeration;

public enum RequestStatus {
    INITIATED,CANCELED,CONTROLED,APPROVED,PROCESSED,REJECTED
}
