package org.sgma.portalrpa.repo;

import org.sgma.portalrpa.entities.RPRole;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RPRoleRepo extends JpaRepository<RPRole,Long> {
}
