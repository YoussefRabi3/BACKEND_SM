package org.sgma.portalrpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortalRpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
